<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bandeja extends Model
{
    protected $table = 'bandeja';
}
